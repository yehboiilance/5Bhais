import os, sys, time
from pynput import keyboard


# keep track of cursor index
cursor_position = 0

# in timer
timer_exist = False

# keep track of state of keys
# 4 bit logic representing state, 1 is pressed, 0 is releaseds
keyState     = 0b00000000
keyStatePrev = 0b00000000

# Functions to read and write to keyState

def read_keyState():
    global keyState
    return keyState

def read_keyStatePrev():
    global keyStatePrev
    return keyStatePrev

def read_cursor_position():
    global cursor_position
    return cursor_position

def read_timer_exist():
    global timer_exist
    return timer_exist

def write_timer_exist(arg):
    global timer_exist
    timer_exist = arg


# switch case for VK dictionaries
# VK_LEFT = left arrow
# VK_UP = up arrow
# VK_RIGHT = right arrow
# VK_DOWN = down arrow
# VK_RETURN = enter

def VK_REG_SWITCH(VK_KEY): 
    
    VK_REG= {

        "VK_LEFT"  : 0b0000001,
        "VK_UP"    : 0b0000010,
        "VK_RIGHT" : 0b0000100,
        "VK_DOWN"  : 0b00001000,
        "VK_RETURN": 0b00010000
    }

    return VK_REG[VK_KEY]


# Define a function to handle key presses
def on_press(key):
    global keyState
    global keyStatePrev

    keyStatePrev = keyState
    
    try:
        # press left arrow key
        if (key == keyboard.Key.left) and ((keyState & VK_REG_SWITCH("VK_LEFT")) == 0):
            # XOR keyState bits
            keyState = keyState ^ VK_REG_SWITCH("VK_LEFT")

        # press up arrow key
        elif (key == keyboard.Key.up) and ((keyState & VK_REG_SWITCH("VK_UP")) == 0):
            # XOR keyState bits
            keyState = keyState ^ VK_REG_SWITCH("VK_UP")

        # press right arrow key
        elif (key == keyboard.Key.right) and ((keyState & VK_REG_SWITCH("VK_RIGHT")) == 0):
            # XOR keyState bits
            keyState = keyState ^ VK_REG_SWITCH("VK_RIGHT")
        
        # press down arrow key
        elif (key == keyboard.Key.down) and ((keyState & VK_REG_SWITCH("VK_DOWN")) == 0):
            # XOR keyState bits
            keyState = keyState ^ VK_REG_SWITCH("VK_DOWN")

        # press enter key
        elif (key == keyboard.Key.enter) and ((keyState & VK_REG_SWITCH("VK_RETURN")) == 0):
            # XOR keyState bits
            keyState = keyState ^ VK_REG_SWITCH("VK_RETURN")
           
           
    except AttributeError:
        print(f"Special key {key} pressed")


# Define a function to handle key releases
def on_release(key):
    global keyState
    global keyStatePrev
    global cursor_position
    global timer_exist
    

    keyStatePrev = keyState
    if key == keyboard.Key.esc:
        # Returning False stops the listener
        return False
    # Stop listener with the ESC key


    # release left arrow key
    if (key == keyboard.Key.left) and (keyState & VK_REG_SWITCH("VK_LEFT") != 0):
        # XOR keyState bits
        keyState = keyState ^ VK_REG_SWITCH("VK_LEFT")

     # release up arrow key
    elif (key == keyboard.Key.up) and (keyState & VK_REG_SWITCH("VK_UP") != 0):
        # XOR keyState bits
        keyState = keyState ^ VK_REG_SWITCH("VK_UP")
         # increment cursor position 
        if  0 < cursor_position:
            cursor_position = cursor_position - 1

    # release right arrow key
    elif (key == keyboard.Key.right) and (keyState & VK_REG_SWITCH("VK_RIGHT") != 0):
        # XOR keyState bits
        keyState = keyState ^ VK_REG_SWITCH("VK_RIGHT")

    # release down arrow key
    elif (key == keyboard.Key.down) and (keyState & VK_REG_SWITCH("VK_DOWN") != 0):
        # XOR keyState bits
        keyState = keyState ^ VK_REG_SWITCH("VK_DOWN")
        if cursor_position < 3:
            cursor_position = cursor_position + 1

    # release enter key
    elif (key == keyboard.Key.enter) and (keyState & VK_REG_SWITCH("VK_RETURN") != 0):
        # XOR keyState bits
        keyState = keyState ^ VK_REG_SWITCH("VK_RETURN")
        timer_exist = True
    

# part of vsync to keep terminal neat and clear
def clear_screen():
    # ANSI escape sequence to clear screen
    sys.stdout.write("\033[2J\033[H")
    sys.stdout.flush()

# detect change in screen
def wake_up(key):
    try:
        if keyStatePrev & keyState != 0:
            print("Screen Changed")
            return False  # Stop the listener
        else:
            print("Same old")
            return False  # Stop the listener
    except AttributeError:
        pass  # Handle special keys


# listens for if there was a keypressed to update display
def wait_for_keypress():
    # Create a listener
    with keyboard.Listener(on_press=wake_up,on_release=wake_up) as listener:
        listener.join()







