Command Line Interface Timer:

Functionality:
- Main menu 
- Keyboard traversal
- 5,10,15,30 second intervals
- Output 3 states for each portion of a focus period 


Requires the following python modules:
- time, os, sys and pynput

To use:
- Make sure all the files are in the same directory. The simple run the main file.

Note:
- Although only arrow keys and enter button are bound to any actions, the event listener does hear all keystrokes. 
- Code is mild spaghetti.

