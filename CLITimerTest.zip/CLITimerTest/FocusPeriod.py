import time, os, sys
from Utilities import *

class FocusPeriod:

    def __init__(self, choice):

        self.focus_time = focus_interval_options(choice)
    

    # partition focus_time_total into 3 parts for the 3 state
    # each part represents a threshold time
    # when the threshold is passed we will know that it is time to switch to the correpsonding state
    # state0: one third of the time has passed
    # state1: two thirds of the time has passed
    # state2: three thirds of the time has passed 

    def focus_time_partition(self, focus_time_total):
        # Calculate the size of each section
        state0 = focus_time_total // 3
        state1 = focus_time_total // 3
        state2 = focus_time_total // 3

        # Distribute the remainder
        remainder = focus_time_total % 3
        if remainder == 1:
            state0 += 1
        elif remainder == 2:
            state0 += 1
            state1 += 1


        state0 = state0
        state1 = state0 + state1
        state2 = state1 + state2
        

        state_time_threshold = [state0, state1, state2]

        return state_time_threshold
    
    
    # countdown for timer 
    def timer(self):

        # initialize necessary variables
        focus_time_total = self.focus_time
        # two values to proc from each other to get incremental index
        focus_time_remaining = focus_time_total
        focus_time_elapsed = focus_time_total - focus_time_remaining

    # partition focus_time_total into thresholds
        state_time_threshold = self.focus_time_partition(focus_time_total)
        
        # start procedure

        # visual countdown before start 
        print("Timer set for ", focus_time_remaining, " seconds")
        print("Starting in")
        for i in range(3,0,-1):
            print(i)
            time.sleep(1)
            
        # keep terminal clear
        clear_screen()

        # stage 0 of growth    
        while(focus_time_elapsed < state_time_threshold[0]):
            
            # update progress 
            print("Time until end of Focus Period: ", focus_time_remaining)
            state_tracker (state_time_threshold,state_time_threshold[0])

            # traverse 1 second interval
            time.sleep(1)
            # update remaining time and elapsed time
            focus_time_remaining -= 1
            focus_time_elapsed = focus_time_total - focus_time_remaining

            # keep terminal clear
            clear_screen()
    
        # stage 1 of growth    
        while(focus_time_elapsed < state_time_threshold[1]):
            
            # update progress 
            print("Time until end of Focus Period: ", focus_time_remaining)
            state_tracker (state_time_threshold,state_time_threshold[1])

            # traverse 1 second interval
            time.sleep(1)
            # update remaining time and elapsed time
            focus_time_remaining -= 1
            focus_time_elapsed = focus_time_total - focus_time_remaining

            # keep terminal clear
            clear_screen()
        
        # stage 2 of growth    
        while(focus_time_elapsed < state_time_threshold[2]):
            
            # update progress 
            print("Time until end of Focus Period: ", focus_time_remaining)
            state_tracker (state_time_threshold,state_time_threshold[2])

            # traverse 1 second interval
            time.sleep(1)
            # update remaining time and elapsed time
            focus_time_remaining -= 1
            focus_time_elapsed = focus_time_total - focus_time_remaining

            # keep terminal clear
            clear_screen()
        
        # keep terminal clear 
        clear_screen()
        print("\nFocus Period Complete\n")
        return 0



   
