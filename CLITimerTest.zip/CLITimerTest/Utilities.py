import sys, os

def focus_interval_options(choice):
    # menu options as dictionary
    menu = {

        "A" : 5, 
        "B" : 10,
        "C" : 15,
        "D" : 30
    }

    return menu[choice]


# pass what state we are in and it will show the state data
def state_tracker (state_time_threshold,currentState):

    state_switch = {
        state_time_threshold[0] : "Currently Displaying State 0", 
        state_time_threshold[1] : "Currently Displaying State 1", 
        state_time_threshold[2] : "Currently Displaying State 2"
    }

    print(state_switch[currentState])

# part of vsync to keep terminal neat and clear
def clear_screen():
    # ANSI escape sequence to clear screen
    sys.stdout.write("\033[2J\033[H")
    sys.stdout.flush()