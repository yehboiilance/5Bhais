from KeyBoardEvent import *

# menu 
def menu():
    # options for menu
    options_highlighted = ["[A] 5 seconds", "[B] 10 seconds", "[C] 15 seconds", "[D] 30 seconds"]
    options_std         = ["A 5 seconds", "B 10 seconds", "C 15 seconds", "D 30 seconds"]
    options_out         = ["A", "B", "C", "D"]

    options_display = options_std

    options_display[read_cursor_position()] = options_highlighted[read_cursor_position()]

    option = options_out[read_cursor_position()]
    option = option.replace("[","")
    option = option.replace("]","")

    # print menu
    for index in range(0,len(options_display), 1):
        print(options_display[index])
    
    return option