from FocusPeriod   import *
from Utilities     import *
from KeyBoardEvent import *
from Menu          import *
from pynput        import keyboard

        
def main():

    global cursor_position

    # open listener to start listening for key input
    listener = keyboard.Listener(on_press=on_press,on_release=on_release)
    listener.start()

    # main loop
    while True:

        #print(f"Current Key State: {read_keyState()}")
        #print(read_cursor_position())
        print('Use the up and down arrow keys and enter to select the focus interval')
        print('Press \'ctrl + C\' to exit')
        choice = menu()
        wait_for_keypress() # detect key press with one listener and 
        clear_screen()

        if(read_timer_exist() != 0):
            newFocusPeriod = FocusPeriod(choice)
            newFocusPeriod.timer()

            #clear_screen()
            write_timer_exist(False)

            
       
    return 0

if __name__ == "__main__":

    try:
        main()
    # Main loop to simulate program execution
        
    except KeyboardInterrupt:
        print("Exiting...")
